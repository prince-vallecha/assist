package com.prince.scheduler

import android.service.voice.VoiceInteractionService

/**
 * Registered in the manifest as the app's voice interaction entry point.
 * Android keeps this alive once the app is selected as the default
 * Digital assistant app. No logic needed here — sessions are what matter.
 */
class SchedulerVoiceInteractionService : VoiceInteractionService()
