package com.prince.scheduler

import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

/**
 * Android calls onNewSession() every time the assist gesture (power-button
 * hold) triggers. Each session is a fresh voice capture cycle.
 */
class SchedulerVoiceInteractionSessionService : VoiceInteractionSessionService() {

    override fun onNewSession(args: Bundle?): VoiceInteractionSession {
        return SchedulerVoiceInteractionSession(this)
    }
}
